# w3stringsr

Converts between Witcher 3 strings CSV sources and `.w3strings` files.

## Usage

```
w3stringsr [OPTIONS] --id-space <[n]nnnn> <SOURCE> [DESTINATION]
w3stringsr [OPTIONS] --decode <SOURCE> [--output <DESTINATION>]
```

| Argument                       | Description                                                |
| ------------------------------ | ---------------------------------------------------------- |
| `<SOURCE>`                     | Source CSV file                                            |
| `<DESTINATION>`                | Output file; defaults to `SOURCE.w3strings` / `SOURCE.csv` |
| `-e`, `--encode <SOURCE>`      | Same as `<SOURCE>`                                         |
| `-d`, `--decode <SOURCE>`      | Decode a `.w3strings` file                                 |
| `-o`, `--output <DESTINATION>` | Same as `<DESTINATION>`                                    |
| `-i`, `--id-space <[n]nnnn>`   | Allowed string ids: `1[n]nnnnNNNN`; `[n]` defaults to `0`  |
| `--no-verify`                  | Skip the id space check                                    |
| `--nextgen`                    | Encode for nextgen using format version 162 UTF-16         |
| `--utf8`                       | Force UTF-8 encoding                                       |
| `--utf16`                      | Force UTF-16 encoding                                      |
| `--no-meta-version`            | Do not write the `;meta[version=..]` line when decoding    |
| `--decode-crlf`                | Write CR and LF in strings as-is when decoding             |
| `-h`, `--help`                 | Print help                                                 |
| `-V`, `--version`              | Print version                                              |

Encoding will default to the source file `;meta[version=..]` if present, otherwise the Remastered Redkit 5.0 format (version 164 UTF-8).

## Source format

```
;meta[language=en]
; id      |key(hex)|key(str)| text
;meta[version=164]
2122144000||LightRewrite|Light Rewrite
2122144001|00abcdef||Second string
```

| Column     | Description                                                         |
| ---------- | ------------------------------------------------------------------- |
| `id`       | String id (`u32`, unique)                                           |
| `key(hex)` | Key hash as hex; `00000000` means no key                            |
| `key(str)` | Key name, hashed case-insensitively; takes priority over `key(hex)` |
| `text`     | String text; empty writes the key with no string, and needs a key   |

Languages: `ar`, `br`, `cleartext`, `cn`, `cz`, `de`, `en`, `es`, `esmx`, `fr`, `hu`, `it`, `jp`, `kr`, `pl`, `ru`, `tr`, `ua`, `zh`.

- `;meta[version=..]` is optional: `162` or `164`, defaults to `164`
- Decoded sources list strings in file order with keys in `key(hex)`
- Decoding a v162 file writes `;meta[version=162]` unless `--no-meta-version` is passed
- Files with a zero header (`ar`, `br`, `cn`, `esmx`, `kr`, `tr`, `ua`) decode as `cleartext`
- String text may contain pipe characters `|`
- String text is copied byte for byte and need not be valid UTF-8, except with `--utf16`

## Examples

```
w3stringsr -i 22144 l10n/en l10n/en.w3strings
w3stringsr -d l10n/en.w3strings -o l10n/en
```
